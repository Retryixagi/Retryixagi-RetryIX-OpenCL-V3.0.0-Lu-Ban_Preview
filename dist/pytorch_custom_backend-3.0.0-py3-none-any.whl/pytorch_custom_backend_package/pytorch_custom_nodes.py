#!/usr/bin/env python3
"""
ComfyUI Custom PyTorch Backend Node
使用自定義PyTorch後端進行GPU加速計算
"""

import torch
import torch.nn as nn
import numpy as np
import sys
import os

# 添加自定義後端路徑
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from pytorch_custom_backend import (
    CustomDevice, CustomTensor, CustomLinear, CustomConv2d,
    CustomMSELoss, custom_tensor, custom_zeros, custom_ones, custom_randn
)

class CustomPyTorchLinear:
    """自定義PyTorch線性層節點"""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "input_tensor": ("TENSOR",),
                "in_features": ("INT", {"default": 10, "min": 1, "max": 4096}),
                "out_features": ("INT", {"default": 5, "min": 1, "max": 4096}),
                "use_bias": ("BOOLEAN", {"default": True}),
            }
        }

    RETURN_TYPES = ("TENSOR",)
    FUNCTION = "apply_linear"
    CATEGORY = "PyTorch Custom"

    def apply_linear(self, input_tensor, in_features, out_features, use_bias):
        try:
            # 創建自定義設備
            device = CustomDevice("custom_gpu")

            # 轉換輸入張量
            if isinstance(input_tensor, torch.Tensor):
                custom_input = CustomTensor(input_tensor.numpy(), device=device)
            else:
                custom_input = CustomTensor(input_tensor, device=device)

            # 創建線性層
            linear = CustomLinear(in_features, out_features, use_bias)

            # 前向傳播
            output = linear(custom_input)

            # 轉回torch張量
            result = torch.from_numpy(output.numpy())

            return (result,)

        except Exception as e:
            print(f"Custom Linear Error: {e}")
            return (input_tensor,)

class CustomPyTorchConv2D:
    """自定義PyTorch 2D卷積層節點"""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "input_tensor": ("IMAGE",),
                "in_channels": ("INT", {"default": 3, "min": 1, "max": 1024}),
                "out_channels": ("INT", {"default": 64, "min": 1, "max": 1024}),
                "kernel_size": ("INT", {"default": 3, "min": 1, "max": 11}),
                "stride": ("INT", {"default": 1, "min": 1, "max": 8}),
                "padding": ("INT", {"default": 1, "min": 0, "max": 8}),
                "use_bias": ("BOOLEAN", {"default": True}),
            }
        }

    RETURN_TYPES = ("IMAGE",)
    FUNCTION = "apply_conv2d"
    CATEGORY = "PyTorch Custom"

    def apply_conv2d(self, input_tensor, in_channels, out_channels, kernel_size, stride, padding, use_bias):
        try:
            # 創建自定義設備
            device = CustomDevice("custom_gpu")

            # 轉換輸入張量 (ComfyUI IMAGE格式: [B, H, W, C] -> [B, C, H, W])
            if isinstance(input_tensor, torch.Tensor):
                # 從[B, H, W, C]轉為[B, C, H, W]
                if input_tensor.dim() == 4:
                    custom_input = CustomTensor(input_tensor.permute(0, 3, 1, 2).numpy(), device=device)
                else:
                    custom_input = CustomTensor(input_tensor.numpy(), device=device)
            else:
                custom_input = CustomTensor(input_tensor, device=device)

            # 創建卷積層
            conv = CustomConv2d(in_channels, out_channels, kernel_size, stride, padding, use_bias)

            # 前向傳播
            output = conv(custom_input)

            # 轉回torch張量並調整格式 [B, C, H, W] -> [B, H, W, C]
            result = torch.from_numpy(output.numpy()).permute(0, 2, 3, 1)

            return (result,)

        except Exception as e:
            print(f"Custom Conv2D Error: {e}")
            return (input_tensor,)

class CustomPyTorchActivation:
    """自定義PyTorch激活函數節點"""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "input_tensor": ("TENSOR",),
                "activation_type": (["relu", "sigmoid", "tanh"], {"default": "relu"}),
            }
        }

    RETURN_TYPES = ("TENSOR",)
    FUNCTION = "apply_activation"
    CATEGORY = "PyTorch Custom"

    def apply_activation(self, input_tensor, activation_type):
        try:
            # 創建自定義設備
            device = CustomDevice("custom_gpu")

            # 轉換輸入張量
            if isinstance(input_tensor, torch.Tensor):
                custom_input = CustomTensor(input_tensor.numpy(), device=device)
            else:
                custom_input = CustomTensor(input_tensor, device=device)

            # 應用激活函數
            if activation_type == "relu":
                output = custom_input.relu()
            elif activation_type == "sigmoid":
                output = custom_input.sigmoid()
            elif activation_type == "tanh":
                output = custom_input.tanh()
            else:
                output = custom_input

            # 轉回torch張量
            result = torch.from_numpy(output.numpy())

            return (result,)

        except Exception as e:
            print(f"Custom Activation Error: {e}")
            return (input_tensor,)

class CustomPyTorchLoss:
    """自定義PyTorch損失函數節點"""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prediction": ("TENSOR",),
                "target": ("TENSOR",),
                "loss_type": (["mse", "mae"], {"default": "mse"}),
            }
        }

    RETURN_TYPES = ("FLOAT",)
    FUNCTION = "compute_loss"
    CATEGORY = "PyTorch Custom"

    def compute_loss(self, prediction, target, loss_type):
        try:
            # 創建自定義設備
            device = CustomDevice("custom_gpu")

            # 轉換輸入張量
            if isinstance(prediction, torch.Tensor):
                custom_pred = CustomTensor(prediction.numpy(), device=device)
            else:
                custom_pred = CustomTensor(prediction, device=device)

            if isinstance(target, torch.Tensor):
                custom_target = CustomTensor(target.numpy(), device=device)
            else:
                custom_target = CustomTensor(target, device=device)

            # 計算損失
            if loss_type == "mse":
                loss_func = CustomMSELoss()
                loss = loss_func(custom_pred, custom_target)
            elif loss_type == "mae":
                # 簡單MAE實現
                diff = custom_pred.data - custom_target.data
                loss_value = np.mean(np.abs(diff))
                loss = CustomTensor(np.array([loss_value]), device=device)
            else:
                loss = CustomTensor(np.array([0.0]), device=device)

            return (float(loss.item()),)

        except Exception as e:
            print(f"Custom Loss Error: {e}")
            return (0.0,)

class CustomPyTorchTensorOps:
    """自定義PyTorch張量操作節點"""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "tensor_a": ("TENSOR",),
                "tensor_b": ("TENSOR",),
                "operation": (["add", "multiply", "matmul"], {"default": "add"}),
            }
        }

    RETURN_TYPES = ("TENSOR",)
    FUNCTION = "apply_operation"
    CATEGORY = "PyTorch Custom"

    def apply_operation(self, tensor_a, tensor_b, operation):
        try:
            # 創建自定義設備
            device = CustomDevice("custom_gpu")

            # 轉換輸入張量
            if isinstance(tensor_a, torch.Tensor):
                custom_a = CustomTensor(tensor_a.numpy(), device=device)
            else:
                custom_a = CustomTensor(tensor_a, device=device)

            if isinstance(tensor_b, torch.Tensor):
                custom_b = CustomTensor(tensor_b.numpy(), device=device)
            else:
                custom_b = CustomTensor(tensor_b, device=device)

            # 應用操作
            if operation == "add":
                result = custom_a + custom_b
            elif operation == "multiply":
                result = custom_a * custom_b
            elif operation == "matmul":
                result = custom_a @ custom_b
            else:
                result = custom_a

            # 轉回torch張量
            output = torch.from_numpy(result.numpy())

            return (output,)

        except Exception as e:
            print(f"Custom Tensor Ops Error: {e}")
            return (tensor_a,)

# 節點映射
NODE_CLASS_MAPPINGS = {
    "CustomPyTorchLinear": CustomPyTorchLinear,
    "CustomPyTorchConv2D": CustomPyTorchConv2D,
    "CustomPyTorchActivation": CustomPyTorchActivation,
    "CustomPyTorchLoss": CustomPyTorchLoss,
    "CustomPyTorchTensorOps": CustomPyTorchTensorOps,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "CustomPyTorchLinear": "Custom Linear Layer",
    "CustomPyTorchConv2D": "Custom Conv2D Layer",
    "CustomPyTorchActivation": "Custom Activation",
    "CustomPyTorchLoss": "Custom Loss Function",
    "CustomPyTorchTensorOps": "Custom Tensor Operations",
}

print("✅ PyTorch Custom Backend ComfyUI nodes loaded successfully!")