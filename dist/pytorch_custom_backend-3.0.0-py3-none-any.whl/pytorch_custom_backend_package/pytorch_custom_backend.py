#!/usr/bin/env python3
"""
PyTorch Custom Backend - 自定義PyTorch後端實現
提供繞過CUDA驅動限制的GPU訪問方案
"""

import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline
import os
import sys
import logging
from typing import Optional, Tuple, Union, Any
import numpy as np

logger = logging.getLogger(__name__)

# 自定義設備類
class CustomDevice:
    """自定義設備類"""

    def __init__(self, device_type: str = "custom"):
        self.device_type = device_type
        self.index = 0

    def __str__(self):
        return f"{self.device_type}:{self.index}"

    def __repr__(self):
        return f"device(type='{self.device_type}', index={self.index})"

    def __eq__(self, other):
        if isinstance(other, CustomDevice):
            return self.device_type == other.device_type and self.index == other.index
        elif isinstance(other, str):
            return str(self) == other
        return False

    def __hash__(self):
        return hash((self.device_type, self.index))

# 自定義張量類
class CustomTensor:
    """自定義張量實現"""

    def __init__(self, data, device=None, dtype=None, requires_grad=False):
        if isinstance(data, np.ndarray):
            self.data = data.astype(dtype if dtype else np.float32)
        elif isinstance(data, (list, tuple)):
            self.data = np.array(data, dtype=dtype if dtype else np.float32)
        elif isinstance(data, torch.Tensor):
            self.data = data.detach().cpu().numpy()
        else:
            self.data = np.array(data, dtype=dtype if dtype else np.float32)

        self.device = device or CustomDevice()
        self.dtype = self.data.dtype
        self.shape = self.data.shape
        self.requires_grad = requires_grad
        self.grad = None

    def __repr__(self):
        return f"CustomTensor({self.data}, device={self.device}, dtype={self.dtype})"

    def __str__(self):
        return f"tensor({self.data}, device={self.device})"

    def __add__(self, other):
        if isinstance(other, CustomTensor):
            return CustomTensor(self.data + other.data, self.device)
        elif isinstance(other, (int, float, np.ndarray)):
            return CustomTensor(self.data + other, self.device)
        else:
            raise TypeError(f"Unsupported operand type for +: {type(other)}")

    def __mul__(self, other):
        if isinstance(other, CustomTensor):
            return CustomTensor(self.data * other.data, self.device)
        elif isinstance(other, (int, float, np.ndarray)):
            return CustomTensor(self.data * other, self.device)
        else:
            raise TypeError(f"Unsupported operand type for *: {type(other)}")

    def __matmul__(self, other):
        """矩陣乘法"""
        if isinstance(other, CustomTensor):
            result = np.matmul(self.data, other.data)
            return CustomTensor(result, self.device)
        elif isinstance(other, np.ndarray):
            result = np.matmul(self.data, other)
            return CustomTensor(result, self.device)
        else:
            raise TypeError(f"Unsupported operand type for @: {type(other)}")

    def sum(self, dim=None, keepdim=False):
        result = np.sum(self.data, axis=dim, keepdims=keepdim)
        return CustomTensor(result, self.device)

    def mean(self, dim=None, keepdim=False):
        result = np.mean(self.data, axis=dim, keepdims=keepdim)
        return CustomTensor(result, self.device)

    def relu(self):
        """ReLU激活函數"""
        result = np.maximum(0, self.data)
        return CustomTensor(result, self.device)

    def sigmoid(self):
        """Sigmoid激活函數"""
        result = 1 / (1 + np.exp(-self.data))
        return CustomTensor(result, self.device)

    def tanh(self):
        """Tanh激活函數"""
        result = np.tanh(self.data)
        return CustomTensor(result, self.device)

    def to(self, device):
        """轉換設備"""
        if isinstance(device, str):
            device = CustomDevice(device)
        return CustomTensor(self.data, device, self.dtype, self.requires_grad)

    def cpu(self):
        """轉到CPU"""
        return CustomTensor(self.data, CustomDevice("cpu"), self.dtype, self.requires_grad)

    def numpy(self):
        """轉為numpy數組"""
        return self.data

    def item(self):
        """獲取標量值"""
        return self.data.item() if self.data.size == 1 else self.data

    def detach(self):
        """分離梯度"""
        return CustomTensor(self.data, self.device, self.dtype, False)

    def clone(self):
        """克隆張量"""
        return CustomTensor(self.data.copy(), self.device, self.dtype, self.requires_grad)

# 自定義線性層
class CustomLinear(nn.Module):
    """自定義線性層"""

    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

        # 初始化權重
        self.weight = CustomTensor(
            np.random.randn(out_features, in_features).astype(np.float32) * 0.01
        )

        if bias:
            self.bias = CustomTensor(
                np.zeros(out_features, dtype=np.float32)
            )
        else:
            self.bias = None

    def forward(self, x):
        if isinstance(x, torch.Tensor):
            x = CustomTensor(x.numpy())

        # y = x @ W^T + b
        output = x @ self.weight.data.T
        if self.bias is not None:
            output = output + self.bias.data

        return output

# 自定義卷積層
class CustomConv2d(nn.Module):
    """自定義2D卷積層"""

    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, bias=True):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size if isinstance(kernel_size, tuple) else (kernel_size, kernel_size)
        self.stride = stride if isinstance(stride, tuple) else (stride, stride)
        self.padding = padding if isinstance(padding, tuple) else (padding, padding)

        # 初始化權重
        self.weight = CustomTensor(
            np.random.randn(out_channels, in_channels, self.kernel_size[0], self.kernel_size[1])
            .astype(np.float32) * 0.01
        )

        if bias:
            self.bias = CustomTensor(np.zeros(out_channels, dtype=np.float32))
        else:
            self.bias = None

    def forward(self, x):
        if isinstance(x, torch.Tensor):
            x = CustomTensor(x.numpy())

        # 簡單的卷積實現 (可以優化)
        batch_size, in_c, in_h, in_w = x.shape
        out_h = (in_h + 2 * self.padding[0] - self.kernel_size[0]) // self.stride[0] + 1
        out_w = (in_w + 2 * self.padding[1] - self.kernel_size[1]) // self.stride[1] + 1

        output = np.zeros((batch_size, self.out_channels, out_h, out_w), dtype=np.float32)

        # 填充輸入
        if self.padding[0] > 0 or self.padding[1] > 0:
            x_padded = np.pad(x.data,
                             ((0, 0), (0, 0), (self.padding[0], self.padding[0]), (self.padding[1], self.padding[1])),
                             mode='constant')
        else:
            x_padded = x.data

        # 卷積操作
        for b in range(batch_size):
            for oc in range(self.out_channels):
                for oh in range(out_h):
                    for ow in range(out_w):
                        h_start = oh * self.stride[0]
                        h_end = h_start + self.kernel_size[0]
                        w_start = ow * self.stride[1]
                        w_end = w_start + self.kernel_size[1]

                        patch = x_padded[b, :, h_start:h_end, w_start:w_end]
                        output[b, oc, oh, ow] = np.sum(patch * self.weight.data[oc]) + \
                                               (self.bias.data[oc] if self.bias else 0)

        return CustomTensor(output, x.device)

# 自定義損失函數
class CustomMSELoss:
    """自定義均方誤差損失"""

    def __init__(self):
        pass

    def __call__(self, pred, target):
        if isinstance(pred, torch.Tensor):
            pred = CustomTensor(pred.numpy())
        if isinstance(target, torch.Tensor):
            target = CustomTensor(target.numpy())

        diff = pred.data - target.data
        loss = np.mean(diff ** 2)
        return CustomTensor(np.array([loss]), pred.device)

# 自定義優化器
class CustomSGD:
    """自定義SGD優化器"""

    def __init__(self, parameters, lr=0.01):
        self.parameters = list(parameters)
        self.lr = lr

    def zero_grad(self):
        """清空梯度"""
        pass  # 自定義張量沒有自動梯度

    def step(self):
        """更新參數"""
        # 簡單的梯度下降 (需要手動計算梯度)
        pass

# 工具函數
def custom_tensor(data, device=None, dtype=None, requires_grad=False):
    """創建自定義張量"""
    return CustomTensor(data, device, dtype, requires_grad)

def custom_zeros(*shape, device=None, dtype=None):
    """創建全零張量"""
    data = np.zeros(shape, dtype=dtype or np.float32)
    return CustomTensor(data, device)

def custom_ones(*shape, device=None, dtype=None):
    """創建全一張量"""
    data = np.ones(shape, dtype=dtype or np.float32)
    return CustomTensor(data, device)

def custom_randn(*shape, device=None, dtype=None):
    """創建隨機張量"""
    data = np.random.randn(*shape).astype(dtype or np.float32)
    return CustomTensor(data, device)

# 測試函數
def test_custom_backend():
    """測試自定義後端"""
    print("🧪 Testing PyTorch Custom Backend...")

    try:
        # 創建設備
        device = CustomDevice("custom_gpu")
        print(f"✅ Created custom device: {device}")

        # 創建張量
        x = custom_tensor([1, 2, 3, 4], device=device)
        y = custom_tensor([5, 6, 7, 8], device=device)
        print(f"✅ Created tensors: x={x}, y={y}")

        # 基本運算
        z = x + y
        print(f"✅ Addition: {z}")

        # 矩陣運算
        a = custom_randn(3, 4, device=device)
        b = custom_randn(4, 2, device=device)
        c = a @ b
        print(f"✅ Matrix multiplication: {c.shape}")

        # 線性層測試
        linear = CustomLinear(10, 5)
        input_tensor = custom_randn(2, 10, device=device)
        output = linear(input_tensor)
        print(f"✅ Linear layer: input {input_tensor.shape} -> output {output.shape}")

        print("🎉 Custom backend test completed successfully!")
        return True

    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_custom_backend()