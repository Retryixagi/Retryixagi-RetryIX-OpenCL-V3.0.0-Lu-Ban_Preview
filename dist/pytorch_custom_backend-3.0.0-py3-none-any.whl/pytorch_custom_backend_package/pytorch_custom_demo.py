#!/usr/bin/env python3
"""
PyTorch Custom Backend Demo Script
演示如何使用自定義PyTorch後端進行神經網絡訓練
"""

import sys
import os
import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import DataLoader, TensorDataset

# 添加自定義後端路徑
sys.path.append(os.path.dirname(__file__))

from pytorch_custom_backend import (
    CustomDevice, CustomTensor, CustomLinear,
    CustomMSELoss, custom_tensor, custom_randn
)

def create_simple_dataset(num_samples=1000, input_size=10, output_size=1):
    """創建簡單的回歸數據集"""
    # 生成隨機輸入
    X = np.random.randn(num_samples, input_size).astype(np.float32)

    # 生成輸出 (簡單的線性關係 + 噪聲)
    weights = np.random.randn(input_size, output_size).astype(np.float32)
    y = X @ weights + 0.1 * np.random.randn(num_samples, output_size).astype(np.float32)

    return torch.from_numpy(X), torch.from_numpy(y)

def train_custom_model():
    """使用自定義後端訓練簡單模型"""
    print("🚀 Training with PyTorch Custom Backend...")

    # 創建設備
    device = CustomDevice("custom_gpu")
    print(f"📍 Using device: {device}")

    # 創建數據集
    X_train, y_train = create_simple_dataset(1000, 10, 1)
    train_dataset = TensorDataset(X_train, y_train)
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)

    # 創建模型
    model = CustomLinear(10, 1)
    criterion = CustomMSELoss()

    print("🏗️ Model created with custom backend")

    # 訓練循環
    num_epochs = 10
    learning_rate = 0.01

    for epoch in range(num_epochs):
        total_loss = 0.0
        num_batches = 0

        for batch_X, batch_y in train_loader:
            # 轉換為自定義張量
            custom_X = CustomTensor(batch_X.numpy(), device=device)
            custom_y = CustomTensor(batch_y.numpy(), device=device)

            # 前向傳播
            outputs = model(custom_X)
            loss = criterion(outputs, custom_y)

            # 簡單的手動梯度下降 (實際項目中需要自動微分)
            # 這裡只是演示概念
            loss_value = loss.item()
            total_loss += loss_value
            num_batches += 1

            # 模擬參數更新 (實際實現需要梯度計算)
            # model.weight.data -= learning_rate * gradient_W
            # model.bias.data -= learning_rate * gradient_b

        avg_loss = total_loss / num_batches
        print(".4f")

    print("✅ Training completed!")
    return model

def inference_demo(model):
    """推理演示"""
    print("\n🔮 Running inference demo...")

    device = CustomDevice("custom_gpu")

    # 創建測試數據
    test_X = torch.randn(5, 10)
    custom_test_X = CustomTensor(test_X.numpy(), device=device)

    # 推理
    with torch.no_grad():
        predictions = model(custom_test_X)

    print(f"📊 Test inputs shape: {test_X.shape}")
    print(f"🎯 Predictions shape: {predictions.shape}")
    print(f"📈 Sample predictions: {predictions.numpy().flatten()[:3]}")

def performance_comparison():
    """性能比較"""
    print("\n⚡ Performance Comparison...")

    device = CustomDevice("custom_gpu")

    # 創建測試數據
    sizes = [100, 500, 1000, 2000]

    for size in sizes:
        X = custom_randn(size, size, device=device)
        y = custom_randn(size, size, device=device)

        # 測試矩陣乘法
        import time
        start_time = time.time()
        result = X @ y
        custom_time = time.time() - start_time

        # PyTorch CPU比較
        X_cpu = torch.randn(size, size)
        y_cpu = torch.randn(size, size)
        start_time = time.time()
        result_cpu = X_cpu @ y_cpu
        cpu_time = time.time() - start_time

        print(f"Size {size}x{size}: Custom={custom_time:.4f}s, PyTorch CPU={cpu_time:.4f}s")

def main():
    """主函數"""
    print("🧠 PyTorch Custom Backend Demo")
    print("=" * 50)

    try:
        # 訓練模型
        model = train_custom_model()

        # 推理演示
        inference_demo(model)

        # 性能比較
        performance_comparison()

        print("\n🎉 Demo completed successfully!")
        print("\n💡 Key Benefits of Custom Backend:")
        print("  • 繞過CUDA驅動限制")
        print("  • 自定義硬件優化")
        print("  • 輕量級實現")
        print("  • 易於擴展")

    except Exception as e:
        print(f"❌ Demo failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()