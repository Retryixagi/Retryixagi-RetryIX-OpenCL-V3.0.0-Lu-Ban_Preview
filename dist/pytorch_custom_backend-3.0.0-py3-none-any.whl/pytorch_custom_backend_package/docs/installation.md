# 安裝指南

## 系統要求

- Python 3.7+
- NumPy 1.21.0+
- Windows 10/11 (針對AMD GPU優化)

## 安裝步驟

### 1. 下載.whl文件

從發行頁面下載最新的 `.whl` 文件：
```
pytorch_custom_backend-1.0.0-py3-none-any.whl
```

### 2. 安裝包

使用pip安裝：

```bash
pip install pytorch_custom_backend-1.0.0-py3-none-any.whl
```

### 3. 驗證安裝

運行Python並檢查導入：

```python
import pytorch_custom_backend
print("安裝成功！")

# 測試基本功能
from pytorch_custom_backend import CustomTensor
a = CustomTensor([1, 2, 3])
print(f"張量創建成功: {a}")
```

## 可選依賴

如果要運行比較測試或使用PyTorch功能：

```bash
pip install torch torchvision
```

## 故障排除

### 安裝失敗

如果遇到權限錯誤，請使用：

```bash
pip install --user pytorch_custom_backend-1.0.0-py3-none-any.whl
```

### 導入錯誤

確保Python路徑正確：

```bash
python -c "import sys; print(sys.path)"
```

### 性能問題

- 確保使用NumPy 1.21.0或更高版本
- 對於AMD GPU，確保系統支持AVX2指令集

## 開發安裝

如果要從源代碼安裝：

```bash
git clone <repository-url>
cd pytorch-custom-backend
pip install -e .
```