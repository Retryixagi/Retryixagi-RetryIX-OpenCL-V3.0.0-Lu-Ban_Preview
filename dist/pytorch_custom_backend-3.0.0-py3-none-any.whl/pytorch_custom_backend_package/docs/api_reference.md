# PyTorch Custom Backend API Reference

## CustomDevice

設備抽象類，用於表示自定義計算設備。

### 方法

- `__init__(device_type: str, index: int = 0)`: 初始化設備
- `__str__()`: 返回設備字符串表示
- `__eq__(other)`: 比較設備相等性

## CustomTensor

自定義張量類，基於NumPy實現。

### 初始化

- `CustomTensor(data)`: 從數據創建張量
- `CustomTensor(shape)`: 創建指定形狀的張量

### 屬性

- `data`: NumPy數組數據
- `shape`: 張量形狀
- `dtype`: 數據類型
- `device`: 設備信息

### 操作符重載

- `+`, `-`, `*`, `/`: 元素級運算
- `@`: 矩陣乘法
- `==`, `!=`: 比較操作

### 方法

- `sum()`: 求和
- `mean()`: 求均值
- `item()`: 獲取標量值
- `reshape(shape)`: 重塑形狀
- `transpose()`: 轉置

## CustomLinear

線性層實現。

### 初始化

- `CustomLinear(in_features: int, out_features: int, bias: bool = True)`

### 屬性

- `weight`: 權重張量
- `bias`: 偏置張量（如果有）

### 方法

- `forward(input: CustomTensor)`: 前向傳播

## CustomConv2d

2D卷積層實現。

### 初始化

- `CustomConv2d(in_channels: int, out_channels: int, kernel_size, stride=1, padding=0)`

### 方法

- `forward(input: CustomTensor)`: 前向傳播

## CustomMSELoss

均方誤差損失函數。

### 方法

- `forward(pred: CustomTensor, target: CustomTensor)`: 計算損失

## 工具函數

### 張量創建

- `custom_tensor(data)`: 創建自定義張量
- `custom_zeros(*shape)`: 創建全零張量
- `custom_ones(*shape)`: 創建全一張量
- `custom_randn(*shape)`: 創建隨機張量

### 設備管理

- `custom_device(device_type: str)`: 創建設備對象

## ComfyUI節點

### CustomLinearNode

線性層ComfyUI節點。

### CustomConv2dNode

卷積層ComfyUI節點。

### CustomTrainingNode

訓練節點。

### CustomInferenceNode

推理節點。

### CustomBenchmarkNode

性能基準測試節點。