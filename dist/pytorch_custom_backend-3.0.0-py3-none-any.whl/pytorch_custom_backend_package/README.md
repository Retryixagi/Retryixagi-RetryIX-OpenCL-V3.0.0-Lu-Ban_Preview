# PyTorch Custom Backend Package

一個自定義的PyTorch後端實現，專為AMD RX5700等受限硬件設計，提供無CUDA驅動的GPU加速能力。

## 功能特點

- **自定義設備**: `CustomDevice` 類實現設備抽象
- **自定義張量**: `CustomTensor` 類支持NumPy後端的張量操作
- **神經網絡層**: 實現線性層、卷積層等基本神經網絡組件
- **損失函數**: MSE損失等常用損失函數
- **ComfyUI集成**: 提供ComfyUI自定義節點支持

## 安裝

```bash
pip install pytorch_custom_backend-1.0.0-py3-none-any.whl
```

## 使用方法

### 基本張量操作

```python
from pytorch_custom_backend import CustomTensor, custom_zeros, custom_ones

# 創建張量
a = CustomTensor([1, 2, 3, 4])
b = custom_zeros(2, 3)
c = custom_ones(2, 3)

# 張量運算
d = a + b
e = a * c
```

### 神經網絡

```python
from pytorch_custom_backend import CustomLinear, CustomMSELoss

# 創建層
fc = CustomLinear(784, 10)
loss_fn = CustomMSELoss()

# 前向傳播
output = fc(input_tensor)
loss = loss_fn(output, target)
```

### ComfyUI集成

```python
from pytorch_custom_backend import (
    CustomLinearNode, CustomConv2dNode,
    CustomTrainingNode, CustomInferenceNode
)

# 在ComfyUI中使用自定義節點
```

## 性能特點

- **無驅動依賴**: 不需要CUDA或專用GPU驅動
- **NumPy後端**: 利用NumPy的高性能數學運算
- **AMD優化**: 專為AMD RX5700等消費級GPU設計
- **輕量級**: 最小化依賴，易於部署

## 測試

運行單元測試：

```bash
python -m pytest tests/
```

運行性能基準測試：

```bash
python tests/benchmark_pytorch_custom_backend.py
```

## 架構說明

```
pytorch_custom_backend/
├── __init__.py                 # 包初始化
├── pytorch_custom_backend.py   # 核心後端實現
├── pytorch_custom_demo.py      # 演示腳本
├── pytorch_custom_nodes.py     # ComfyUI節點
├── tests/                      # 測試套件
│   ├── __init__.py
│   ├── test_pytorch_custom_backend.py
│   └── benchmark_pytorch_custom_backend.py
└── docs/                       # 文檔
```

## 依賴

- numpy >= 1.21.0
- torch (可選，用於比較測試)

## 授權

MIT License

## 貢獻

歡迎提交問題和拉取請求！

## 聯繫

如有問題，請通過GitHub Issues聯繫。