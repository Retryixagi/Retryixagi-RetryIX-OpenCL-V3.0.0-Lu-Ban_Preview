#!/usr/bin/env python3
"""
PyTorch Custom Backend - GPU Acceleration Without CUDA Drivers

This package provides a custom PyTorch backend implementation that enables
GPU-accelerated computing without requiring CUDA drivers. It's particularly
useful for environments where CUDA installation is not possible or desired.

Main Features:
- Custom device and tensor implementations
- Neural network layers (Linear, Conv2D)
- Activation functions and loss functions
- ComfyUI integration support
- Hardware-agnostic design
"""

__version__ = "1.0.0"
__author__ = "AI Developer"
__email__ = "ai@example.com"
__license__ = "MIT"
__description__ = "Custom PyTorch backend for GPU acceleration without CUDA drivers"

# Import main classes for easy access
from .pytorch_custom_backend import (
    CustomDevice,
    CustomTensor,
    CustomLinear,
    CustomConv2d,
    CustomMSELoss,
    custom_tensor,
    custom_zeros,
    custom_ones,
    custom_randn,
)

# ComfyUI nodes (optional import)
try:
    from .pytorch_custom_nodes import (
        CustomPyTorchLinear,
        CustomPyTorchConv2D,
        CustomPyTorchActivation,
        CustomPyTorchLoss,
        CustomPyTorchTensorOps,
        NODE_CLASS_MAPPINGS,
        NODE_DISPLAY_NAME_MAPPINGS,
    )
    COMFYUI_AVAILABLE = True
except ImportError:
    COMFYUI_AVAILABLE = False

def main():
    """Main entry point for command line usage"""
    from .pytorch_custom_demo import main as demo_main
    demo_main()

if __name__ == "__main__":
    main()