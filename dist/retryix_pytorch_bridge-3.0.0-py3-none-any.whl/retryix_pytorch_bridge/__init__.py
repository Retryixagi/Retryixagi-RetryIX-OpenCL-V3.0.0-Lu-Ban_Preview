"""
RetryIX PyTorch Bridge

這個模組提供PyTorch與RetryIX純C AI庫的橋接，讓PyTorch可以利用
RetryIX的高性能AI實現，包括神經網路、CNN、Transformer等。
"""

import os
import sys
import ctypes
import torch
import numpy as np
from typing import Optional, Tuple, Union, List
import warnings

__version__ = "3.0.0"
__author__ = "RetryIX Team"

class RetryIXError(Exception):
    """RetryIX相關錯誤"""
    pass

class RetryIXPyTorchBridge:
    """
    RetryIX與PyTorch的橋接類

    提供將PyTorch張量與RetryIX純C AI函數整合的接口
    """

    def __init__(self, dll_path: Optional[str] = None):
        """
        初始化橋接

        Args:
            dll_path: RetryIX DLL路徑，如果為None則自動尋找
        """
        self.dll = None
        self._load_library(dll_path)
        self._initialize_bridge()

    def _load_library(self, dll_path: Optional[str] = None):
        """載入RetryIX動態庫"""
        if dll_path is None:
            # 自動尋找DLL
            script_dir = os.path.dirname(os.path.abspath(__file__))
            workspace_root = os.path.dirname(script_dir)

            possible_paths = [
                os.path.join(workspace_root, "lib", "retryix.dll"),  # Windows
                os.path.join(workspace_root, "lib", "libretryix.so"), # Linux
                "retryix.dll",  # PATH中尋找
            ]

            for path in possible_paths:
                if os.path.exists(path):
                    dll_path = path
                    break

        if dll_path is None or not os.path.exists(dll_path):
            raise RetryIXError(f"找不到RetryIX庫: {dll_path}")

        try:
            self.dll = ctypes.CDLL(dll_path)
            print(f"成功載入RetryIX庫: {dll_path}")
        except Exception as e:
            raise RetryIXError(f"載入RetryIX庫失敗: {e}")

    def _initialize_bridge(self):
        """初始化橋接"""
        if hasattr(self.dll, 'retryix_initialize'):
            result = self.dll.retryix_initialize()
            if result != 0:
                warnings.warn(f"RetryIX初始化返回非零值: {result}")

    def tensor_to_retryix(self, tensor: torch.Tensor) -> Tuple[ctypes.c_void_p, Tuple[int, ...]]:
        """
        將PyTorch張量轉換為RetryIX可用的格式

        Args:
            tensor: PyTorch張量

        Returns:
            (數據指針, 形狀元組)
        """
        if not tensor.is_contiguous():
            tensor = tensor.contiguous()

        # 獲取張量數據指針
        data_ptr = tensor.data_ptr()

        # 獲取形狀
        shape = tuple(tensor.shape)

        return ctypes.c_void_p(data_ptr), shape

    def retryix_to_tensor(self, data_ptr: ctypes.c_void_p,
                         shape: Tuple[int, ...],
                         dtype: torch.dtype = torch.float32,
                         device: Optional[torch.device] = None) -> torch.Tensor:
        """
        將RetryIX數據轉換為PyTorch張量

        Args:
            data_ptr: RetryIX數據指針
            shape: 張量形狀
            dtype: 數據類型
            device: 設備

        Returns:
            PyTorch張量
        """
        if device is None:
            device = torch.device('cpu')

        # 計算數據大小
        size = int(np.prod(shape))

        # 創建NumPy數組視圖
        if dtype == torch.float32:
            np_dtype = np.float32
        elif dtype == torch.float64:
            np_dtype = np.float64
        elif dtype == torch.int32:
            np_dtype = np.int32
        elif dtype == torch.int64:
            np_dtype = np.int64
        else:
            raise ValueError(f"不支持的數據類型: {dtype}")

        # 從指針創建數組
        arr = np.ctypeslib.as_array(ctypes.cast(data_ptr, ctypes.POINTER(np_dtype)), shape=(size,))

        # 重塑為正確形狀
        arr = arr.reshape(shape)

        # 轉換為PyTorch張量
        tensor = torch.from_numpy(arr).to(dtype=dtype, device=device)

        return tensor

    def matrix_multiply(self, a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
        """
        使用RetryIX進行矩陣乘法

        Args:
            a: 輸入張量A (M x K)
            b: 輸入張量B (K x N)

        Returns:
            結果張量 (M x N)
        """
        if a.dim() != 2 or b.dim() != 2:
            raise ValueError("輸入必須是2D張量")

        M, K = a.shape
        K2, N = b.shape

        if K != K2:
            raise ValueError(f"矩陣維度不匹配: {a.shape} @ {b.shape}")

        # 準備輸出張量
        c = torch.empty((M, N), dtype=a.dtype, device=a.device)

        # 轉換為RetryIX格式
        a_ptr, _ = self.tensor_to_retryix(a)
        b_ptr, _ = self.tensor_to_retryix(b)
        c_ptr, _ = self.tensor_to_retryix(c)

        # 調用RetryIX矩陣乘法 (如果存在)
        if hasattr(self.dll, 'retryix_ai_matrix_multiply'):
            func = self.dll.retryix_ai_matrix_multiply
            func.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                           ctypes.c_int, ctypes.c_int, ctypes.c_int]
            func.restype = ctypes.c_int

            result = func(a_ptr, b_ptr, c_ptr, M, K, N)
            if result != 0:
                raise RetryIXError(f"RetryIX矩陣乘法失敗: {result}")
        else:
            # Fallback到PyTorch實現
            warnings.warn("RetryIX矩陣乘法函數不可用，使用PyTorch實現")
            c = torch.matmul(a, b)

        return c

    def conv2d(self, input: torch.Tensor, weight: torch.Tensor,
               bias: Optional[torch.Tensor] = None,
               stride: int = 1, padding: int = 0) -> torch.Tensor:
        """
        使用RetryIX進行2D卷積

        Args:
            input: 輸入張量 (N x C x H x W)
            weight: 權重張量 (out_channels x in_channels x kH x kW)
            bias: 偏置張量 (可選)
            stride: 步長
            padding: 填充

        Returns:
            輸出張量
        """
        # 這裡實現與RetryIX CNN的橋接
        # 目前返回PyTorch實現作為fallback

        if hasattr(self.dll, 'retryix_ai_conv2d'):
            # TODO: 實現RetryIX conv2d橋接
            pass

        # Fallback到PyTorch
        return torch.nn.functional.conv2d(input, weight, bias, stride, padding)

    def transformer_attention(self, query: torch.Tensor, key: torch.Tensor,
                            value: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        使用RetryIX進行Transformer注意力機制

        Args:
            query: 查詢張量
            key: 鍵張量
            value: 值張量
            mask: 注意力遮罩 (可選)

        Returns:
            注意力輸出
        """
        if hasattr(self.dll, 'retryix_ai_attention'):
            # TODO: 實現RetryIX注意力橋接
            pass

        # Fallback到PyTorch實現
        # 簡化的注意力計算
        scores = torch.matmul(query, key.transpose(-2, -1)) / (query.size(-1) ** 0.5)

        if mask is not None:
            scores = scores.masked_fill(mask == 0, float('-inf'))

        attention_weights = torch.softmax(scores, dim=-1)
        output = torch.matmul(attention_weights, value)

        return output

    def __del__(self):
        """清理資源"""
        if hasattr(self.dll, 'retryix_cleanup') and self.dll:
            try:
                self.dll.retryix_cleanup()
            except:
                pass  # 忽略清理錯誤

# 全局橋接實例
_bridge_instance: Optional[RetryIXPyTorchBridge] = None

def get_bridge(dll_path: Optional[str] = None) -> RetryIXPyTorchBridge:
    """
    獲取全局RetryIX-PyTorch橋接實例

    Args:
        dll_path: RetryIX DLL路徑

    Returns:
        橋接實例
    """
    global _bridge_instance
    if _bridge_instance is None:
        _bridge_instance = RetryIXPyTorchBridge(dll_path)
    return _bridge_instance

def matrix_multiply(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """
    便捷函數：矩陣乘法

    Args:
        a: 輸入張量A
        b: 輸入張量B

    Returns:
        結果張量
    """
    return get_bridge().matrix_multiply(a, b)

def conv2d(input: torch.Tensor, weight: torch.Tensor,
          bias: Optional[torch.Tensor] = None,
          stride: int = 1, padding: int = 0) -> torch.Tensor:
    """
    便捷函數：2D卷積

    Args:
        input: 輸入張量
        weight: 權重張量
        bias: 偏置張量
        stride: 步長
        padding: 填充

    Returns:
        輸出張量
    """
    return get_bridge().conv2d(input, weight, bias, stride, padding)

def attention(query: torch.Tensor, key: torch.Tensor, value: torch.Tensor,
             mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    """
    便捷函數：注意力機制

    Args:
        query: 查詢張量
        key: 鍵張量
        value: 值張量
        mask: 注意力遮罩

    Returns:
        注意力輸出
    """
    return get_bridge().transformer_attention(query, key, value, mask)

# 版本信息
def get_version() -> str:
    """獲取橋接版本"""
    return __version__

def get_retryix_version() -> Optional[str]:
    """獲取RetryIX庫版本"""
    try:
        bridge = get_bridge()
        if hasattr(bridge.dll, 'retryix_get_version'):
            func = bridge.dll.retryix_get_version
            func.restype = ctypes.c_char_p
            version_ptr = func()
            if version_ptr:
                return version_ptr.decode('utf-8')
    except:
        pass
    return None